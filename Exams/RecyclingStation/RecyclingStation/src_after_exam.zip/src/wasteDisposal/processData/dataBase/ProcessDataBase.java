package wasteDisposal.processData.dataBase;

import wasteDisposal.processData.ProcessingData;

import java.util.List;

public interface ProcessDataBase {

    List<ProcessingData> getProcessingDatas();
}
