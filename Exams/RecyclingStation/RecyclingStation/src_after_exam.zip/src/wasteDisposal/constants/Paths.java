package wasteDisposal.constants;

public class Paths {

    public static final String COMMANDS_PACKAGE_PATH = "wasteDisposal.commands.commands.";

    public static final String STRATEGIES_PACKAGE_PATH = "wasteDisposal.strategies.";

    public static final String WASTE_PACKAGE_PATH = "wasteDisposal.waste.";
}
