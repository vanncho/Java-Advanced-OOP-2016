package wasteDisposal.constants;

public class Messages {

    public static final String SPLIT_INPUT_REGEX = "[\\s\\|]";

    public static final String PROCESS_GARABAGE_COMMAND = "ProcessGarbage";

    public static final String PROCESS_GARABAGE_SUCCSESSFUL = "%.2f kg of %s successfully processed!";

    public static final String END_COMMAND = "TimeToRecycle";
}
