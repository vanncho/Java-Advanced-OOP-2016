import wasteDisposal.commands.status.StatusCommands;
import wasteDisposal.commands.status.StatusCommandsImpl;
import wasteDisposal.commands.waste.WasteCommands;
import wasteDisposal.commands.waste.WasteCommandsImpl;
import wasteDisposal.engine.ApplicationRun;
import wasteDisposal.engine.Runnable;
import wasteDisposal.io.reader.ConsoleReader;
import wasteDisposal.io.reader.Reader;
import wasteDisposal.io.writer.ConsoleWriter;
import wasteDisposal.io.writer.Writer;

public class Main {
    public static void main(String[] args) {

        StatusCommands statusCommands = new StatusCommandsImpl();
        WasteCommands wasteCommands = new WasteCommandsImpl();
        Reader consoleReader = new ConsoleReader();
        Writer consoleWriter = new ConsoleWriter();

        Runnable applicationRun = new ApplicationRun(statusCommands, wasteCommands, consoleReader, consoleWriter);
        applicationRun.run();
    }
}
