package wasteDisposal.io.writer;

public interface Writer {

    void writeLine(String line);
}
