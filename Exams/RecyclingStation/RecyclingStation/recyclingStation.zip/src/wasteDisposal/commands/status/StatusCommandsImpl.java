package wasteDisposal.commands.status;

import wasteDisposal.commands.Executable;
import wasteDisposal.constants.Paths;

import java.lang.reflect.Constructor;

public class StatusCommandsImpl implements StatusCommands {

    public StatusCommandsImpl() {
    }

    @Override
    public Executable interpretCoreCommand(String[] data) {
        Executable executable = null;

        String commandName = data[0];
        String path = Paths.STATUS_COMMANDS_PACKAGE_PATH + commandName + "Command";

        try {
            Class executableClass = Class.forName(path);
            Constructor constructor = executableClass.getDeclaredConstructor(String[].class);
            constructor.setAccessible(true);
            executable = (Executable) constructor.newInstance((Object) data);

        } catch (ReflectiveOperationException e) {
            e.printStackTrace();
        }

        return executable;
    }
}
