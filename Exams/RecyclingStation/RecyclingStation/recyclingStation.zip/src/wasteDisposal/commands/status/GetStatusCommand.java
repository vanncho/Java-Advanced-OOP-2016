package wasteDisposal.commands.status;

import wasteDisposal.commands.Command;

public class GetStatusCommand extends Command {

    protected GetStatusCommand(String[] data) {
        super(data);
    }

    @Override
    public String execute() {

        return null;
    }
}
