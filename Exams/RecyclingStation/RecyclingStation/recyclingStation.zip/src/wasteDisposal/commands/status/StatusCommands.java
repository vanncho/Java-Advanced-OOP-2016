package wasteDisposal.commands.status;

import wasteDisposal.commands.Executable;

public interface StatusCommands {

    Executable interpretCoreCommand(String[] data);
}
