package wasteDisposal.commands.waste;

import wasteDisposal.commands.Executable;

public interface WasteCommands {

    Executable interpretCoreCommand(String[] data);
}
