package wasteDisposal.commands.waste;

import wasteDisposal.annotations.Inject;
import wasteDisposal.commands.Command;
import wasteDisposal.constants.Messages;
import wasteDisposal.enumerations.GarbageType;
import wasteDisposal.factories.WasteCreator;
import wasteDisposal.processors.GarbageProcessor;
import wasteDisposal.waste.Waste;

public class ProcessGarbageCommand extends Command {

    @Inject
    private WasteCreator wasteCreator;
    @Inject
    private GarbageProcessor garbageProcessor;

    protected ProcessGarbageCommand(String[] data) {
        super(data);
    }

    @Override
    public String execute() {

        String wasteName = this.getData()[0];
        double weight = Double.valueOf(this.getData()[1]);
        double volumePerKg = Double.valueOf(this.getData()[2]);
        GarbageType garbageType = GarbageType.valueOf(this.getData()[3]);

        Waste waste = this.wasteCreator.create(wasteName, weight, volumePerKg, garbageType);
        this.garbageProcessor.processWaste(waste);

        return String.format(Messages.PROCESS_GARABAGE_SUCCSESSFUL, weight, wasteName);
    }
}
