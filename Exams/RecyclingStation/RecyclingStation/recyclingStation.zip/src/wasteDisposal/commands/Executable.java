package wasteDisposal.commands;

public interface Executable {

    String execute();
}