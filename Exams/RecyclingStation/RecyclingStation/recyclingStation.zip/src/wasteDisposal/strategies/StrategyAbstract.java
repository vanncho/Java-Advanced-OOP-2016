package wasteDisposal.strategies;

public abstract class StrategyAbstract implements GarbageDisposalStrategy {

    protected StrategyAbstract() {
    }
}
