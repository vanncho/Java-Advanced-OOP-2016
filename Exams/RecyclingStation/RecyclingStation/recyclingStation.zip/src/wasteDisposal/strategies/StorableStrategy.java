package wasteDisposal.strategies;

import wasteDisposal.constants.Values;
import wasteDisposal.processData.ConcreteProcessingData;
import wasteDisposal.processData.ProcessingData;
import wasteDisposal.waste.Waste;

public class StorableStrategy extends StrategyAbstract {

    private ProcessingData dataForProcess;

    public StorableStrategy() {
    }

    @Override
    public ProcessingData processGarbage(Waste garbage) {

        double energyUsed = (garbage.getWeight() * garbage.getVolumePerKg()) * Values.STORABLE_ENERGY_USED_MULTIPLY_UNIT;
        double capitalUsed = (garbage.getWeight() * garbage.getVolumePerKg()) * Values.STORABLE_CAPITAL_USED_MULTIPLY_UNIT;

        double energyBalance = energyUsed - Values.STORABLE_ENERGY_PRODUCED;
        double capitalBalance = capitalUsed - Values.STORABLE_CAPITAL_EARNED;

        this.dataForProcess = new ConcreteProcessingData(energyBalance, capitalBalance);
        return dataForProcess;
    }
}
