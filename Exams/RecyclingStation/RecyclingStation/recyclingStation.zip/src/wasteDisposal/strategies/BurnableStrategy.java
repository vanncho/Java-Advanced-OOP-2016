package wasteDisposal.strategies;

import wasteDisposal.constants.Values;
import wasteDisposal.processData.ConcreteProcessingData;
import wasteDisposal.processData.ProcessingData;
import wasteDisposal.waste.Waste;

public class BurnableStrategy extends StrategyAbstract {

    private ProcessingData dataForProcess;

    public BurnableStrategy() {
    }

    @Override
    public ProcessingData processGarbage(Waste garbage) {

        double energyBalance = (garbage.getWeight() * garbage.getVolumePerKg()) * Values.BURNABLE_ENERGY_USED_MULTIPLY_UNIT;
        double capitalBalance = Values.BURNABLE_CAPITAL_EARNED - Values.BURNABLE_CAPITAL_USED;

        this.dataForProcess = new ConcreteProcessingData(energyBalance, capitalBalance);
        return dataForProcess;
    }
}
