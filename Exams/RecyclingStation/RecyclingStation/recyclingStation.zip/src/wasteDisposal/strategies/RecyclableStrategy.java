package wasteDisposal.strategies;

import wasteDisposal.constants.Values;
import wasteDisposal.processData.ConcreteProcessingData;
import wasteDisposal.processData.ProcessingData;
import wasteDisposal.waste.Waste;

public class RecyclableStrategy extends StrategyAbstract {

    private ProcessingData dataForProcess;

    public RecyclableStrategy() {
    }

    @Override
    public ProcessingData processGarbage(Waste garbage) {

        double energyUsed = (garbage.getWeight() * garbage.getVolumePerKg()) * Values.RECYCLABLE_ENERGY_USED_MULTIPLY_UNIT;
        double capitalEarned = Values.RECYCLABLE_CAPITAL_EARNED_MULTIPLY_UNIT * garbage.getWeight();

        double energyBalance = energyUsed - Values.RECYCLABLE_ENERGY_PRODUCED;
        double capitalBalance = capitalEarned - Values.RECYCLABLE_CAPITAL_USED;

        this.dataForProcess = new ConcreteProcessingData(energyBalance, capitalBalance);
        return dataForProcess;
    }
}
