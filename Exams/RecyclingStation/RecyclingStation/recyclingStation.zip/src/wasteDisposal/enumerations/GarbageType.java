package wasteDisposal.enumerations;

public enum GarbageType {

    RECYCLABLE,
    BURNABLE,
    STORABLE
}
