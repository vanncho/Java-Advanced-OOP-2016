package wasteDisposal.factories;

import wasteDisposal.constants.Paths;
import wasteDisposal.enumerations.GarbageType;
import wasteDisposal.waste.Waste;

import java.lang.reflect.Constructor;

public class WasteFactory implements WasteCreator {

    public WasteFactory() {
    }

    @Override
    public Waste create(String name, double weight, double volumePerKg, GarbageType garbageType) {

        Waste waste = null;

        try {
            Class coreClass = Class.forName(Paths.WASTE_PACKAGE_PATH + "Garbage");
            Constructor ctor = coreClass.getConstructor(String.class, double.class, double.class, GarbageType.class);
            waste = (Waste) ctor.newInstance(name, weight, volumePerKg, garbageType);

            return waste;

        } catch (ReflectiveOperationException roe) {
            return null;
        }
    }
}
