package wasteDisposal.waste;

import wasteDisposal.enumerations.GarbageType;

public class Garbage extends WasteAbstract {

    public Garbage(String name, double volumePerKg, double weight, GarbageType garbageType) {
        super(name, volumePerKg, weight, garbageType);
    }
}
