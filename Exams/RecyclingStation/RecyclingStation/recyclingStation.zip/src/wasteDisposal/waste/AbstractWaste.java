package wasteDisposal.waste;

import wasteDisposal.enumerations.GarbageType;

public abstract class AbstractWaste implements Waste {

    private String name;
    private double volumePerKg;
    private double weight;
    private GarbageType garbageType;

    protected AbstractWaste(String name, double volumePerKg, double weight, GarbageType garbageType) {
        this.setName(name);
        this.setVolumePerKg(volumePerKg);
        this.setWeight(weight);
        this.setGarbageType(garbageType);
    }

    @Override
    public String getName() {
        return this.name;
    }

    private void setName(String name) {
        this.name = name;
    }

    @Override
    public double getVolumePerKg() {
        return this.volumePerKg;
    }

    private void setVolumePerKg(double volumePerKg) {
        this.volumePerKg = volumePerKg;
    }

    @Override
    public double getWeight() {
        return this.weight;
    }

    private void setWeight(double weight) {
        this.weight = weight;
    }

    public GarbageType getGarbageType() {
        return garbageType;
    }

    private void setGarbageType(GarbageType garbageType) {
        this.garbageType = garbageType;
    }
}
