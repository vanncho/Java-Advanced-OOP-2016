package wasteDisposal.engine;

public interface Runnable {

    void run();
}
