package wasteDisposal.engine;

import wasteDisposal.commands.Executable;
import wasteDisposal.commands.status.StatusCommands;
import wasteDisposal.commands.waste.WasteCommands;
import wasteDisposal.constants.Messages;
import wasteDisposal.io.reader.Reader;
import wasteDisposal.io.writer.Writer;

import java.io.IOException;

public class ApplicationRun implements Runnable {

    private StatusCommands statusCommands;
    private WasteCommands wasteCommands;
    private Reader reader;
    private Writer writer;

    public ApplicationRun(StatusCommands statusCommands, WasteCommands wasteCommands, Reader reader, Writer writer) {
        this.statusCommands = statusCommands;
        this.wasteCommands = wasteCommands;
        this.reader = reader;
        this.writer = writer;
    }

    @Override
    public void run() {

        try {
            while (true) {

                String input = this.reader.readLine();

                if (input.equals(Messages.END_COMMAND)) {
                    break;
                }

                String[] data = input.split(Messages.SPLIT_INPUT_REGEX);

                Executable executableCommand = null;

                if (data[0].equals(Messages.PROCESS_GARABAGE_COMMAND)) {
                    executableCommand = this.wasteCommands.interpretCoreCommand(data);
                } else {
                    executableCommand = this.statusCommands.interpretCoreCommand(data);
                }

                String result = executableCommand.execute();
                this.writer.writeLine(result);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
