package wasteDisposal.constants;

public class Paths {

    public static final String STATUS_COMMANDS_PACKAGE_PATH = "wasteDisposal.commands.status.";

    public static final String WASTE_COMMANDS_PACKAGE_PATH = "wasteDisposal.commands.waste.";

    public static final String WASTE_PACKAGE_PATH = "wasteDisposal.commands.waste.";
}
