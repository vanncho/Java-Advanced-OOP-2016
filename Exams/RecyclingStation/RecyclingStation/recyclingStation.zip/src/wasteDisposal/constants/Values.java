package wasteDisposal.constants;

public class Values {

    // Recyclable strategy
    public static double RECYCLABLE_CAPITAL_EARNED_MULTIPLY_UNIT = 400;
    public static double RECYCLABLE_ENERGY_USED_MULTIPLY_UNIT = 0.5;
    public static double RECYCLABLE_ENERGY_PRODUCED = 0;
    public static double RECYCLABLE_CAPITAL_USED = 0;

    // Burnable strategy
    public static double BURNABLE_ENERGY_USED_MULTIPLY_UNIT = 0.8;
    public static double BURNABLE_CAPITAL_USED = 0;
    public static double BURNABLE_CAPITAL_EARNED = 0;

    // Storable strategy
    public static double STORABLE_ENERGY_USED_MULTIPLY_UNIT = 0.65;
    public static double STORABLE_CAPITAL_USED_MULTIPLY_UNIT = 0.13;
    public static double STORABLE_ENERGY_PRODUCED = 0;
    public static double STORABLE_CAPITAL_EARNED = 0;
}
