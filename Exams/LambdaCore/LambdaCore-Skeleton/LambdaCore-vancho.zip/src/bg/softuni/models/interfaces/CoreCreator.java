package bg.softuni.models.interfaces;

public interface CoreCreator {

    Core create(String coreType, int durability);
}
