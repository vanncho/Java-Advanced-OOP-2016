package bg.softuni.models.interfaces;

public interface CoreCommands {

    Executable interpretCoreCommand(String[] data);
}
