package bg.softuni.models.models.cores;

import bg.softuni.models.collections.LStack;
import bg.softuni.models.engines.CorePressureType;
import bg.softuni.models.interfaces.Core;
import bg.softuni.models.interfaces.Fragment;
import bg.softuni.models.interfaces.FragmentStack;

public abstract class CoreAbstract implements Core {

    private String name;
    private int durability;
    private FragmentStack<Fragment> fragmentsToCore;
    private int corePressure;
    private CorePressureType corePressureType;

    protected CoreAbstract(String name, int durability) {
        this.setName(name);
        this.setDurability(durability);
        this.fragmentsToCore = new LStack<>();
        this.setCorePressure(0);
        this.setCorePressureType(CorePressureType.NORMAL);
    }

    private void setCorePressureType(CorePressureType corePressureType) {
        this.corePressureType = corePressureType;
    }

    private int getCorePressure() {
        return corePressure;
    }

    private void setCorePressure(int corePressure) {
        this.corePressure = corePressure;
    }

    private void setName(String name) {
        this.name = name;
    }

    private void setDurability(int durability) {
        this.durability = durability;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public int getDurability() {
        return this.durability;
    }

    @Override
    public void attachFragment(Fragment fragment) {

        int fragmentPressure = fragment.getPressureAffection();
        String fragmentType = fragment.getType().name().toUpperCase();

        switch (fragmentType) {

            case"NUCLEAR":
                this.setCorePressure(this.getCorePressure() + fragmentPressure);
                this.checkCorePressureStatus(fragmentPressure);
                break;
            case "COOLING":
                this.setCorePressure(this.getCorePressure() - fragmentPressure);
                this.checkCorePressureStatus(fragmentPressure);
                break;
        }

        this.fragmentsToCore.push(fragment);
    }

    @Override
    public Fragment detachFragment() {
        Fragment fragment = this.fragmentsToCore.pop();

        int fragmentPressure = fragment.getPressureAffection();

        this.setCorePressure(this.getCorePressure() - fragmentPressure);
        this.checkCorePressureStatus(fragmentPressure);

        return fragment;
    }

    @Override
    public FragmentStack<Fragment> getAllFragments() {
        return this.fragmentsToCore;
    }

    @Override
    public String toString() {

        return "Core " + this.getName() + ":" + System.lineSeparator() +
                "####Durability: " + this.getDurability() + System.lineSeparator() +
                "####Status: " + this.corePressureType;
    }

    private void checkCorePressureStatus(int fragmentPressure) {

        if (this.getCorePressure() <= 0) {
            this.setCorePressureType(CorePressureType.NORMAL);
        } else if (this.getCorePressure() > 0) {
            this.setCorePressureType(CorePressureType.CRITICAL);
            this.setDurability(this.getDurability() - fragmentPressure);
        }
    }
}
