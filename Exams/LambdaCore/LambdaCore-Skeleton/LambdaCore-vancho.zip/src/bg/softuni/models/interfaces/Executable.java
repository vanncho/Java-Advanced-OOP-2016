package bg.softuni.models.interfaces;

public interface Executable {

    String execute();
}
