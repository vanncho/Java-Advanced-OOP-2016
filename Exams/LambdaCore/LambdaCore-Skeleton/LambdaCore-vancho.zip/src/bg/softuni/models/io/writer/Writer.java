package bg.softuni.models.io.writer;

public interface Writer {

    void writeLine(String line);
}
