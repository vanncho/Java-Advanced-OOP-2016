package bg.softuni.models.enums;

public enum CoreType {

    SYSTEM,
    PARA
}
