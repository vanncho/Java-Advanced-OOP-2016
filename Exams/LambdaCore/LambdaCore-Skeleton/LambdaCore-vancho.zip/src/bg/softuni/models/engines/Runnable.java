package bg.softuni.models.engines;

public interface Runnable {

    void run();
}
