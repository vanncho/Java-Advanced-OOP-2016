package bg.softuni.models.io.reader;

import java.io.IOException;

public interface Reader {

    String readLine() throws IOException;
}
