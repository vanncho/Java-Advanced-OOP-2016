package bg.softuni.models.interfaces;

public interface FragmentCommands {

    Executable interpretCoreCommand(String[] data);
}
