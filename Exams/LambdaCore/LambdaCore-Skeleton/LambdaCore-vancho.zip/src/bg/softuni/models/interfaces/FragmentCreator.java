package bg.softuni.models.interfaces;

public interface FragmentCreator {

    Fragment create(String fragmentType, String fragmentName, int pressureAffection);
}
