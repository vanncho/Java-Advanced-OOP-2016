package bg.softuni.models.enums;

public enum FragmentType {

    NUCLEAR,
    COOLING
}
