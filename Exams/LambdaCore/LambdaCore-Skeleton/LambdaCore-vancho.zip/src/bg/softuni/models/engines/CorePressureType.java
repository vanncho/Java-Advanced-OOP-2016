package bg.softuni.models.engines;

public enum CorePressureType {

    NORMAL,
    CRITICAL
}
