package bg.softuni.models.models.cores;

public class SystemCore extends CoreAbstract {

    public SystemCore(String name, int durability) {
        super(name, durability);
    }
}
