package bg.softuni.models.models.cores;

public class ParaCore{
    public ParaCore(String name, Integer durability) {
    }

}
