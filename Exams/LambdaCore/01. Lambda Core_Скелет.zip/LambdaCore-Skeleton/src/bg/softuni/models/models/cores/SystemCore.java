package bg.softuni.models.models.cores;

public class SystemCore{
    public SystemCore(String name, Integer durability) {

    }
}
