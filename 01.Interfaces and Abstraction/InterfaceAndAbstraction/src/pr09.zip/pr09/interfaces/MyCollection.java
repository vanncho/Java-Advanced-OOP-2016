package pr09.interfaces;

public interface MyCollection extends AddCollection, AddRemoveCollection, MyList {
}
