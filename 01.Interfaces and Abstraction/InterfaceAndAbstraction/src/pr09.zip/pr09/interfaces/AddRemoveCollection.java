package pr09.interfaces;

public interface AddRemoveCollection extends AddCollection {

    String myRemove();
}
