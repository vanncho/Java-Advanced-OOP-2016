package pr09.interfaces;

public interface AddCollection {

    int myAdd(String element);
}
