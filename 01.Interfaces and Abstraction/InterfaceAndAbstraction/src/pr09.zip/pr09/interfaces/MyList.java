package pr09.interfaces;

public interface MyList extends AddRemoveCollection {

    int myUsed();
}
