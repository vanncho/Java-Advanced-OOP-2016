package pr09.models;

import pr09.interfaces.MyCollection;

public abstract class CollectionImpl implements MyCollection {

    public CollectionImpl() {
    }
}
